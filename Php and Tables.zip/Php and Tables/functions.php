<?php
$conn = mysqli_connect("127.0.0.1", "root", "Password1234", "root");



if (isset($_POST["import"])) {

$fileName = $_FILES["file"]["tmp_name"];
if ($_FILES["file"]["size"] > 0) {

    $file = fopen($fileName, "r");

    while (($column = fgetcsv($file, 10000, ",")) !== FALSE) {
        $sqlInsert = "INSERT into Sections Values('$column[0]',$column[1],'$column[2]','$column[3]',
        $column[4],'$column[5]','$column[6]','$column[7]','$column[8]','$column[9]','$column[10]',
      '$column[11]','$column[12]','$column[13]','$column[14]','$column[15]','$column[16]','$column[17]',
    '$column[18]','$column[19]','$column[20]')";
        $result = mysqli_query($conn, $sqlInsert);

        if (!empty($result)) {
            $type = 'success';
            $message = 'CSV Data Imported into the Database';
        } else {
            $type = 'error';
            $message = 'Problem in Importing CSV Data';
        }
    }
}
}
?>
